from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = "secret123"
from flask import Flask, render_template, request, redirect, session, jsonify
import sqlite3
import config
import pandas as pd
from datetime import datetime
import pandas as pd
from flask import send_file
import sqlite3

app = Flask(__name__)
app.secret_key = "secret"

conn = sqlite3.connect("inventory.db", check_same_thread=False)
cursor = conn.cursor()

# CREATE TABLES
cursor.execute("""
CREATE TABLE IF NOT EXISTS inventory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER,
    material_id TEXT,
    name TEXT,
    quantity INTEGER,
    type TEXT,
    date TEXT,
    unit_price REAL,
    total_price REAL,
    purpose TEXT,
    taken_by TEXT,
    phone TEXT,
    return_status TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT
)
""")

# 🔥 ADD INVENTORY EXTRA COLUMNS
inventory_columns = [
    "issue_date TEXT",
    "return_date TEXT",
    "returned_by TEXT",
    "remarks TEXT",
    "returned_qty INTEGER DEFAULT 0",
    "usage_type TEXT DEFAULT 'Returnable'"
]

for col in inventory_columns:
    try:
        cursor.execute(f"ALTER TABLE inventory ADD COLUMN {col}")
        print(f"✅ Added inventory column: {col}")
    except:
        pass

# 🔥 ADD PROJECT SUBFOLDER SUPPORT
try:
    cursor.execute("ALTER TABLE projects ADD COLUMN parent_id INTEGER")
    print("✅ Added parent_id column")
except:
    print("ℹ️ parent_id already exists")

conn.commit()

@app.route("/project_view/<int:project_id>")
def project_view(project_id):

    cursor.execute("SELECT name FROM projects WHERE id=?", (project_id,))
    project_name = cursor.fetchone()[0]

    cursor.execute("""
        SELECT id, name FROM projects
        WHERE parent_id=?
    """, (project_id,))

    subprojects = cursor.fetchall()

    return render_template(
        "project_view.html",
        project_name=project_name,
        subprojects=subprojects,
        project_id=project_id
    )


# 🔐 LOGIN
from flask import flash

@app.route("/", methods=["GET","POST"])
def login():

    if request.method == "POST":
        user = request.form.get("user")
        password = request.form.get("pass")

        print("DEBUG:", user, password)   # 👈 check console

        if user in config.USERS:
            if config.USERS[user]["password"] == password:
                session["user"] = user
                session["role"] = config.USERS[user]["role"]
                return redirect("/projects")
            else:
                return "Wrong Password ❌"
        else:
            return "User not found ❌"

    return render_template("login.html", company=config.COMPANY_NAME)

from functools import wraps

def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if session.get("role") != "admin":
            return "Access Denied ❌ (Admin only)"
        return f(*args, **kwargs)
    return wrapper


from functools import wraps
from flask import redirect, session

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user" not in session:
            return redirect("/")
        return f(*args, **kwargs)
    return wrapper

#LOGOUT
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

# import logging

# logging.basicConfig(
#     filename='error.log',
#     level=logging.ERROR,
#     format='%(asctime)s %(levelname)s %(message)s'
# )

#ISSUES
@app.route("/issue")
@login_required
def issue():

    project_id = session.get("project_id")

    if not project_id:
        return redirect("/projects")

    cursor.execute("SELECT id, name, parent_id FROM projects WHERE id=?", (project_id,))
    row = cursor.fetchone()

    if not row:
        session.clear()
        return redirect("/projects")

    current_id, current_name, parent_id = row

    if parent_id:
        main_project_id = parent_id
        subfolder_name = current_name

        cursor.execute("SELECT name FROM projects WHERE id=?", (parent_id,))
        project_name = cursor.fetchone()[0]
    else:
        main_project_id = current_id
        project_name = current_name
        subfolder_name = ""

    session["main_project_id"] = main_project_id

    return render_template(
        "issue.html",
        active="issue",
        project_name=project_name,
        subfolder_name=subfolder_name,
        current_project_id=project_id
    )

@app.route("/add_issue", methods=["POST"])
@admin_required
def add_issue():

    if "project_id" not in session:
        return "No project selected"

    project_id = session["project_id"]

    material_id = request.form["id"]
    name = request.form["name"]
    qty = int(request.form["qty"])
    taken_by = request.form["taken_by"]
    purpose = request.form["purpose"]
    issue_type = request.form.get("issue_type", "Returnable")

    # 🔥 CORRECT STOCK CALCULATION
    cursor.execute("""
        SELECT 
        SUM(
            CASE
                WHEN type='Purchase' THEN quantity
                WHEN type='Issue' THEN -quantity
                ELSE 0
            END
        )
        +
        SUM(
            CASE
                WHEN type='Issue' AND usage_type='Returnable'
                THEN COALESCE(returned_qty, 0)
                ELSE 0
            END
        )
        FROM inventory
        WHERE material_id=? AND project_id=?
    """, (material_id, project_id))

    stock = cursor.fetchone()[0] or 0

    if qty > stock:
        return f"Only {stock} items available"

    # 🔥 TYPE LOGIC
    if issue_type == "Used":
        status = "Closed"
        returned_qty = qty
        return_date = datetime.now().strftime("%Y-%m-%d")
    else:
        status = "Pending"
        returned_qty = 0
        return_date = None

    cursor.execute("""
        INSERT INTO inventory
        (project_id, material_id, name, quantity, type, date,
         taken_by, purpose, return_status, issue_date,
         returned_qty, return_date, usage_type)
        VALUES (?, ?, ?, ?, 'Issue', date('now'),
                ?, ?, ?, date('now'), ?, ?, ?)
    """, (
        project_id,
        material_id,
        name,
        qty,
        taken_by,
        purpose,
        status,
        returned_qty,
        return_date,
        issue_type
    ))

    conn.commit()
    return "OK"

@app.route("/get_issue_data")
def get_issue_data():

    project_id = session.get("project_id")

    if not project_id:
        return jsonify([])

    # ✅ NEW CURSOR (avoid recursive error)
    cur = conn.cursor()

    cur.execute("""
        SELECT id, material_id, name, quantity,
               taken_by, purpose, issue_date,
               return_status, returned_qty, return_date
        FROM inventory
        WHERE type='Issue' AND project_id=?
    """, (project_id,))

    return jsonify(cur.fetchall())


@app.route("/select_project/<int:id>")
def select_project(id):

    cursor.execute("SELECT id, parent_id FROM projects WHERE id=?", (id,))
    row = cursor.fetchone()

    if not row:
        return redirect("/projects")

    project_id, parent_id = row

    # ✅ CURRENT PROJECT (SUBFOLDER)
    session["project_id"] = project_id

    # ✅ MAIN PROJECT
    if parent_id:
        session["main_project_id"] = parent_id
    else:
        session["main_project_id"] = project_id

    return redirect("/issue")   # 🔥 IMPORTANT

# 📊 DASHBOARD
@login_required
@app.route("/dashboard")
def dashboard():

    project_id = session.get("project_id")

    if not project_id:
        return redirect("/projects")

    # GET CURRENT PROJECT
    cursor.execute("SELECT id, name, parent_id FROM projects WHERE id=?", (project_id,))
    row = cursor.fetchone()

    if not row:
        session.clear()
        return redirect("/projects")

    current_id, current_name, parent_id = row

    # 🔥 MAIN PROJECT + SUBFOLDER LOGIC
    if parent_id:
        main_project_id = parent_id
        subfolder_name = current_name   # ✅ subfolder

        cursor.execute("SELECT name FROM projects WHERE id=?", (parent_id,))
        project_name = cursor.fetchone()[0]   # ✅ main project

    else:
        main_project_id = current_id
        project_name = current_name
        subfolder_name = ""   # ✅ no subfolder

    # STORE MAIN PROJECT
    session["main_project_id"] = main_project_id

    return render_template(
        "dashboard.html",
        active="dashboard",
        project_name=project_name,
        subfolder_name=subfolder_name,
        current_project_id=project_id
    )
    
@app.route("/get_material_name/<mid>")
def get_material_name(mid):

    cursor.execute("""
        SELECT name FROM inventory
        WHERE material_id=?
        ORDER BY id DESC LIMIT 1
    """, (mid,))

    row = cursor.fetchone()
    return row[0] if row else ""

@app.route("/api/dashboard")
def dashboard_api():

    project_id = session.get("main_project_id")

    cursor.execute("""
    SELECT p.name, i.material_id, i.name,

    SUM(
        CASE
            WHEN i.type='Purchase' THEN i.quantity
            WHEN i.type='Issue' THEN -i.quantity
            ELSE 0
        END
    )
    +
    SUM(
        CASE
            WHEN i.type='Issue' AND i.usage_type='Returnable'
            THEN COALESCE(i.returned_qty, 0)
            ELSE 0
        END
    ) AS stock,

    (
        SELECT MAX(unit_price)
        FROM inventory p2
        WHERE p2.material_id = i.material_id
        AND p2.project_id = i.project_id
        AND p2.type='Purchase'
        AND unit_price > 0
    ) AS unit_price

    FROM inventory i
    JOIN projects p ON i.project_id = p.id

    WHERE i.project_id=? OR p.parent_id=?

    GROUP BY i.project_id, i.material_id
    """, (project_id, project_id))

    data = []

    for r in cursor.fetchall():

        project, mid, name, stock, price = r

        stock = int(stock or 0)
        price = float(price or 0)

        total = stock * price

        data.append([project, mid, name, stock, price, total])

    return jsonify(data)

@app.route("/projects", methods=["GET", "POST"])
def projects():

    if request.method == "POST":
        name = request.form["name"]

        cursor.execute(
            "INSERT INTO projects (name, parent_id) VALUES (?, NULL)",
            (name,)
        )
        conn.commit()

    # ONLY MAIN PROJECTS
    cursor.execute("""
        SELECT id, name 
        FROM projects 
        WHERE parent_id IS NULL
    """)

    data = cursor.fetchall()

    return render_template("projects.html", active="projects", data=data)

#SEARCH
@app.route("/search_material")
def search_material():

    q = request.args.get("q", "").lower()
    project_id = session.get("project_id")

    cursor.execute("""
        SELECT material_id, name,
        SUM(
            CASE
                WHEN type='Purchase' THEN quantity
                WHEN type='Issue' THEN -quantity
                ELSE 0
            END
        )
        +
        SUM(
            CASE
                WHEN type='Issue' AND usage_type='Returnable'
                THEN COALESCE(returned_qty, 0)
                ELSE 0
            END
        ) as stock
        FROM inventory
        WHERE project_id=? AND (LOWER(material_id) LIKE ? OR LOWER(name) LIKE ?)
        GROUP BY material_id
    """, (project_id, f"%{q}%", f"%{q}%"))

    return jsonify(cursor.fetchall())


# 📦 PURCHASE PAGE
@app.route("/purchase")
@login_required
def purchase():

    project_id = session.get("project_id")

    if not project_id:
        return redirect("/projects")

    cursor.execute("SELECT id, name, parent_id FROM projects WHERE id=?", (project_id,))
    row = cursor.fetchone()

    if not row:
        session.clear()
        return redirect("/projects")

    current_id, current_name, parent_id = row

    if parent_id:
        main_project_id = parent_id
        subfolder_name = current_name

        cursor.execute("SELECT name FROM projects WHERE id=?", (parent_id,))
        project_name = cursor.fetchone()[0]
    else:
        main_project_id = current_id
        project_name = current_name
        subfolder_name = ""

    session["main_project_id"] = main_project_id

    return render_template(
        "purchase.html",
        active="purchase",
        project_name=project_name,
        subfolder_name=subfolder_name,
        current_project_id=project_id
    )

# AJAX ADD   
@app.route("/add_purchase", methods=["POST"])
@admin_required
def add_purchase():

    if "project_id" not in session:
        return "No project selected"

    project_id = session["project_id"]

    name = request.form["name"]
    qty = int(request.form["qty"])
    price = float(request.form["price"])
    purpose = request.form["purpose"]

    # ✅ CHECK IF MATERIAL ALREADY EXISTS
    cursor.execute("""
        SELECT material_id, quantity
        FROM inventory
        WHERE project_id=? AND name=? AND type='Purchase'
    """, (project_id, name))

    existing = cursor.fetchone()

    if existing:
        # 🔁 MERGE QUANTITY
        material_id = existing[0]

        cursor.execute("""
            UPDATE inventory
            SET quantity = quantity + ?,
                total_price = total_price + ?
            WHERE project_id=? AND material_id=? AND type='Purchase'
        """, (qty, qty * price, project_id, material_id))

    else:
        # 🔢 AUTO GENERATE MATERIAL ID (PER PROJECT)
        cursor.execute("""
            SELECT COUNT(DISTINCT material_id)
            FROM inventory
            WHERE project_id=?
        """, (project_id,))

        count = cursor.fetchone()[0] + 1
        material_id = str(count).zfill(3)

        # ➕ INSERT NEW
        cursor.execute("""
            INSERT INTO inventory
            (project_id, material_id, name, quantity, type, date, unit_price, total_price, purpose)
            VALUES (?, ?, ?, ?, 'Purchase', date('now'), ?, ?, ?)
        """, (
            project_id,
            material_id,
            name,
            qty,
            price,
            qty * price,
            purpose
        ))

    conn.commit()
    return "OK"

@app.route("/get_purchase_data")
def get_purchase_data():

    project_id = session.get("project_id")

    cursor.execute("""
    SELECT material_id, name, quantity, unit_price, purpose,

    (
        SELECT 
        SUM(
            CASE
                WHEN type='Purchase' THEN quantity
                WHEN type='Issue' THEN -quantity
                ELSE 0
            END
        ) 
        +
        SUM(
            CASE
                WHEN type='Issue' AND usage_type='Returnable'
                THEN COALESCE(returned_qty, 0)
                ELSE 0
            END
        )
        FROM inventory i2
        WHERE i2.material_id = i1.material_id
        AND i2.project_id = i1.project_id
    ) as stock,

    id

    FROM inventory i1
    WHERE type='Purchase' AND project_id=?
    """, (project_id,))

    return jsonify(cursor.fetchall())

@app.route("/get_stock")
def get_stock():

    project_id = session.get("project_id")

    cursor.execute("""
    SELECT 
        i.material_id, 
        i.name,

        -- STOCK
        SUM(
            CASE
                WHEN i.type='Purchase' THEN i.quantity
                WHEN i.type='Issue' THEN -i.quantity
                ELSE 0
            END
        )
        +
        SUM(
            CASE
                WHEN i.type='Issue' AND i.usage_type='Returnable'
                THEN COALESCE(i.returned_qty, 0)
                ELSE 0
            END
        ) AS stock,

        -- UNIT PRICE (latest purchase)
        (
            SELECT MAX(unit_price)
            FROM inventory p
            WHERE p.material_id = i.material_id
            AND p.project_id = i.project_id
            AND p.type='Purchase'
            AND unit_price > 0
        ) AS unit_price

    FROM inventory i
    WHERE i.project_id=?
    GROUP BY i.project_id, i.material_id
    """, (project_id,))

    result = []

    for row in cursor.fetchall():
        material_id, name, stock, unit_price = row

        stock = stock or 0
        unit_price = unit_price or 0

        total_price = stock * unit_price   # ✅ ADD HERE

        result.append([material_id, name, stock, unit_price, total_price])

    return jsonify(result)

@app.route("/add_project", methods=["POST"])
def add_project():

    name = request.form["name"]

    cursor.execute("INSERT INTO projects (name) VALUES (?)", (name,))
    conn.commit()

    return "OK"

@app.route("/add_subproject", methods=["POST"])
def add_subproject():

    parent_id = request.form["parent_id"]
    name = request.form["name"]

    cursor.execute("""
        INSERT INTO projects (name, parent_id)
        VALUES (?, ?)
    """, (name, parent_id))

    conn.commit()
    return "OK"

@app.route("/rename_subproject", methods=["POST"])
def rename_subproject():

    id = request.form.get("id")
    name = request.form.get("name")

    conn = sqlite3.connect("inventory.db")
    cursor = conn.cursor()

    cursor.execute(
        "UPDATE projects SET name=? WHERE id=?",
        (name, id)
    )

    conn.commit()
    conn.close()

    return "OK"

@app.route("/delete_subproject", methods=["POST"])
def delete_subproject():

    id = request.form.get("id")

    conn = sqlite3.connect("inventory.db")
    cursor = conn.cursor()

    cursor.execute(
        "DELETE FROM projects WHERE id=?",
        (id,)
    )

    conn.commit()
    conn.close()

    return "OK"


# @app.route("/get_projects")
# def get_projects():

#     cursor.execute("SELECT id, name, parent_id FROM projects")
#     return jsonify(cursor.fetchall())

@app.route("/get_projects")
def get_projects():

    try:
        cursor.execute("SELECT id, name, parent_id FROM projects")
        data = cursor.fetchall()

        return jsonify(data)

    except Exception as e:
        print("ERROR in get_projects:", e)   # 🔥 will show in terminal
        return jsonify([])   # prevent crash

@app.route("/switch_project/<int:id>")
def switch_project(id):

    cursor.execute("SELECT id, parent_id FROM projects WHERE id=?", (id,))
    row = cursor.fetchone()

    if not row:
        return redirect("/projects")

    project_id, parent_id = row

    session["project_id"] = project_id

    if parent_id:
        session["main_project_id"] = parent_id
    else:
        session["main_project_id"] = project_id

    return redirect("/dashboard")

@app.route("/update_purchase", methods=["POST"])
@admin_required
def update_purchase():

    cursor.execute("""
        UPDATE inventory
        SET material_id=?, name=?, quantity=?, unit_price=?, purpose=?
        WHERE id=?
    """, (
        request.form["id"],
        request.form["name"],
        request.form["qty"],
        request.form["price"],
        request.form["purpose"],
        request.form["edit_id"]
    ))

    conn.commit()
    return "OK"
# AJAX GET
@app.route("/get_data")
def get_data():
    cursor.execute("""
    SELECT material_id, name,
    SUM(CASE WHEN type='Purchase' THEN quantity ELSE -quantity END)
    FROM inventory
    WHERE project_id=?
    GROUP BY material_id
    """, (session["project_id"],))

    return jsonify(cursor.fetchall())

@app.route("/reset")
def reset():

    cursor.execute("DELETE FROM inventory")
    cursor.execute("DELETE FROM projects")

    conn.commit()

    return "All data cleared"


@app.route("/delete_project/<int:id>")
def delete_project(id):

    # delete inventory first
    cursor.execute("DELETE FROM inventory WHERE project_id=?", (id,))

    # delete project
    cursor.execute("DELETE FROM projects WHERE id=?", (id,))

    conn.commit()

    return redirect("/projects")

@app.route("/return")
def return_page():

    if "project_id" not in session:
        return redirect("/projects")

    return render_template("return.html", active="return")

#RETURN"
@app.route("/return_item", methods=["POST"])
@admin_required
def return_item():

    id = request.form["id"]
    qty = int(request.form["qty"])
    return_date = request.form["return_date"]

    # GET CURRENT DATA
    cursor.execute("""
        SELECT quantity, returned_qty
        FROM inventory
        WHERE id=? AND type='Issue'
    """, (id,))
    
    row = cursor.fetchone()

    if not row:
        return "Invalid item"

    issued, returned = row

    remaining = issued - returned

    # 🚨 VALIDATION
    if qty > remaining:
        return "Return exceeds remaining quantity"

    new_returned = returned + qty

    # ✅ FINAL STATUS
    status = "Closed" if new_returned == issued else "Pending"

    # ✅ UPDATE
    cursor.execute("""
        UPDATE inventory
        SET returned_qty=?,
            return_status=?,
            return_date=?
        WHERE id=?
    """, (new_returned, status, return_date, id))

    conn.commit()

    return "OK"

@app.route("/get_return_data")
def get_return_data():

    cursor.execute("""
        SELECT material_id, returned_qty, taken_by, return_date, purpose
        FROM inventory
        WHERE type='Issue' AND returned_qty > 0 AND project_id=?
    """, (session["project_id"],))

    return jsonify(cursor.fetchall())

@app.route("/delete_item", methods=["POST"])
@admin_required
def delete_item():

    item_id = request.form["id"]

    cursor.execute("SELECT material_id, project_id FROM inventory WHERE id=?", (item_id,))
    row = cursor.fetchone()

    material_id, project_id = row

    cursor.execute("""
        SELECT SUM(quantity), SUM(returned_qty)
        FROM inventory
        WHERE material_id=? AND project_id=? AND type='Issue'
    """, (material_id, project_id))

    issued, returned = cursor.fetchone()

    if issued and issued != returned:
        return "Cannot delete: items still pending"

    cursor.execute("DELETE FROM inventory WHERE id=?", (item_id,))
    conn.commit()

    return "OK"

@app.route("/get_materials")
def get_materials():

    project_id = session.get("project_id")

    cursor.execute("""
        SELECT material_id, name,
        SUM(
            CASE
                WHEN type='Purchase' THEN quantity
                WHEN type='Issue' THEN -quantity
                ELSE 0
            END
        )
        +
        SUM(
            CASE
                WHEN type='Issue' AND usage_type='Returnable'
                THEN COALESCE(returned_qty, 0)
                ELSE 0
            END
        ) AS stock

        FROM inventory
        WHERE project_id=?
        GROUP BY material_id
    """, (project_id,))

    return jsonify(cursor.fetchall())

@app.route("/update_item", methods=["POST"])
def update_item():
    cursor.execute("""
        UPDATE inventory SET quantity=? WHERE id=?
    """, (request.form["qty"], request.form["id"]))
    conn.commit()
    return "OK"

#RENAME
@app.route("/rename_project/<int:id>/<name>")
def rename_project(id, name):
    cursor.execute("UPDATE projects SET name=? WHERE id=?", (name, id))
    conn.commit()
    return redirect("/projects")

# @app.route("/export")
# def export():

#     import pandas as pd
#     from flask import send_file, session
#     import sqlite3
#     from openpyxl.styles import Font
#     from openpyxl import load_workbook

#     project_id = session.get("project_id")

#     conn = sqlite3.connect("inventory.db")

#     # ✅ PURCHASE (PROJECT BASED)
#     purchase = pd.read_sql_query("""
#         SELECT 
#         ROW_NUMBER() OVER() as "S.No",
#         material_id as "Material ID",
#         name as "Material Name",
#         quantity as "Quantity Purchased",
#         purpose as "Purpose",
#         unit_price as "Unit Price",
#         total_price as "Total Price",
#         date as "Date"
#         FROM inventory
#         WHERE type='Purchase' AND project_id=?
#     """, conn, params=(project_id,))


#     # ✅ ISSUE (PROJECT BASED)
#     issue = pd.read_sql_query("""
#         SELECT 
#         ROW_NUMBER() OVER() as "S.No",
#         material_id as "Material ID",
#         name as "Material Name",
#         quantity as "Quantity",
#         taken_by as "Taken By",
#         purpose as "Purpose",
#         return_status as "Status",
#         issue_date as "Issue Date",
#         return_date as "Return Date"
#         FROM inventory
#         WHERE type='Issue' AND project_id=?
#     """, conn, params=(project_id,))


#     # ✅ STOCK (CORRECT LOGIC)
#     stock = pd.read_sql_query("""
#         SELECT 
#         material_id as "Material ID",
#         name as "Material Name",
#         SUM(
#             CASE
#                 WHEN type='Purchase' THEN quantity
#                 WHEN type='Return' THEN quantity
#                 WHEN type='Issue' THEN -quantity
#             END
#         ) as "Available Stock"
#         FROM inventory
#         WHERE project_id=?
#         GROUP BY material_id
#     """, conn, params=(project_id,))


#     # ✅ EXPORT FILE
#     file = f"Stock_Report.xlsx"

#     with pd.ExcelWriter(file, engine="openpyxl") as writer:
#         purchase.to_excel(writer, sheet_name="Purchase", index=False)
#         issue.to_excel(writer, sheet_name="Issue", index=False)
#         stock.to_excel(writer, sheet_name="Stock", index=False)

#     # ✅ ADD BOLD HEADERS
#     wb = load_workbook(file)

#     for sheet in wb.sheetnames:
#         ws = wb[sheet]

#         for cell in ws[1]:
#             cell.font = Font(bold=True)

#     wb.save(file)

#     return send_file(file, as_attachment=True)

@app.route("/export")
def export():

    import pandas as pd
    from flask import send_file, session
    import sqlite3
    from openpyxl.styles import Font
    from openpyxl import load_workbook

    conn = sqlite3.connect("inventory.db")

    main_project_id = session.get("main_project_id")

    cursor = conn.cursor()

    cursor.execute("""
    SELECT id FROM projects
    WHERE id=? OR parent_id=?
    """, (main_project_id, main_project_id))

    project_ids = [str(r[0]) for r in cursor.fetchall()]
    ids = ",".join(project_ids)

    # 🔥 PURCHASE
    purchase = pd.read_sql_query(f"""
        SELECT 
        ROW_NUMBER() OVER() as "S.No",
        project_id as "Project",
        material_id as "Material ID",
        name as "Material Name",
        quantity as "Quantity Purchased",
        purpose as "Purpose",
        unit_price as "Unit Price",
        total_price as "Total Price",
        date as "Date"
        FROM inventory
        WHERE type='Purchase' AND project_id IN ({ids})
    """, conn)

    # 🔥 ISSUE
    issue = pd.read_sql_query(f"""
        SELECT 
        ROW_NUMBER() OVER() as "S.No",
        project_id as "Project",
        material_id as "Material ID",
        name as "Material Name",
        quantity as "Quantity",
        taken_by as "Taken By",
        purpose as "Purpose",
        return_status as "Status",
        issue_date as "Issue Date",
        return_date as "Return Date"
        FROM inventory
        WHERE type='Issue' AND project_id IN ({ids})
    """, conn)

    # 🔥 STOCK
    stock = pd.read_sql_query(f"""
        SELECT 
        project_id as "Project",
        material_id as "Material ID",
        name as "Material Name",
        SUM(
            CASE
                WHEN type='Purchase' THEN quantity
                WHEN type='Return' THEN quantity
                WHEN type='Issue' THEN -quantity
            END
        ) as "Available Stock"
        FROM inventory
        WHERE project_id IN ({ids})
        GROUP BY project_id, material_id
    """, conn)

    file = "Stock_Report.xlsx"

    with pd.ExcelWriter(file, engine="openpyxl") as writer:
        purchase.to_excel(writer, sheet_name="Purchase", index=False)
        issue.to_excel(writer, sheet_name="Issue", index=False)
        stock.to_excel(writer, sheet_name="Stock", index=False)

    wb = load_workbook(file)

    for sheet in wb.sheetnames:
        for cell in wb[sheet][1]:
            cell.font = Font(bold=True)

    wb.save(file)

    return send_file(file, as_attachment=True)

app.run(debug=True)